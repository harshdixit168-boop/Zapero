# Tavero MVP

A deployable PHP + JSON storage MVP for an AI-powered tutoring platform.

## Included
- Teacher / Student / Parent demo roles
- Teacher dashboard
- AI Lesson Studio
- File upload/library
- Saved lessons
- Tutor directory
- Responsive UI
- SQLite persistence
- Optional OpenAI Responses API integration

## Deploy on PHP hosting
1. Upload the entire folder to your hosting public directory.
2. Make sure PHP has cURL enabled.
3. Make `uploads/` and `data/` writable by PHP.
4. Visit `index.php`.
5. Demo login password is `demo`.

## AI setup
Set the environment variable `OPENAI_API_KEY` on your server. Optionally set `OPENAI_MODEL` (default is `gpt-5.6-luna`). Without an API key, the lesson generator runs in local demo mode so you can test the UI.

## Demo accounts
- teacher@tavero.demo
- student@tavero.demo
- parent@tavero.demo

Password: `demo`

## Important before production
This is an MVP, not a production child-safety/privacy/payment system. Before real U.S. students use it, add proper authentication, authorization, encrypted/secure file storage, consent and child-safety workflows, audit logs, backups, rate limits, payment processing, email verification, password hashing, and legal/privacy review.
