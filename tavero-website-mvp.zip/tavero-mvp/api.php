<?php
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || ($_GET['action'] ?? '') !== 'lesson') { http_response_code(404); echo json_encode(['message'=>'Not found']); exit; }
$input=json_decode(file_get_contents('php://input'), true) ?: [];
$topic=trim($input['topic'] ?? ''); $grade=$input['grade'] ?? 'Grade 7'; $subject=$input['subject'] ?? 'Mathematics'; $duration=$input['duration'] ?? '60 minutes'; $goal=$input['goal'] ?? '';
if(!$topic){http_response_code(422); echo json_encode(['message'=>'Topic is required']); exit;}
$key=getenv('OPENAI_API_KEY');
if(!$key){
 echo json_encode(['title'=>"$subject — $topic",'content'=>"Demo lesson generated locally\n\nGrade: $grade\nDuration: $duration\n\n1. Warm-up (5 min)\nConnect the topic to a simple real-world example.\n\n2. Teach (15 min)\nIntroduce the core concept with 2 worked examples.\n\n3. Guided practice (15 min)\nWork through 3 problems with the student.\n\n4. Independent practice (10 min)\nGive 4 differentiated questions.\n\n5. Exit ticket (5 min)\nAsk 3 short questions to check understanding.\n\nLearning goal: $goal\n\nSet OPENAI_API_KEY on the server to enable live AI generation."]); exit; }
$payload=[
 'model'=>getenv('OPENAI_MODEL') ?: 'gpt-5.6-luna',
 'input'=>"Create a teacher-ready lesson plan. Grade: $grade. Subject: $subject. Topic: $topic. Duration: $duration. Learning goal: $goal. Include: objective, prerequisite check, warm-up, clear explanation, worked examples, guided practice, independent practice, differentiation, formative assessment, homework, and answer key where appropriate. Keep it practical and age-appropriate for a U.S. student."
];
$ch=curl_init('https://api.openai.com/v1/responses'); curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>60]);
$raw=curl_exec($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
if($code<200||$code>=300){http_response_code(500); echo json_encode(['message'=>'OpenAI request failed','details'=>json_decode($raw,true)]); exit;}
$j=json_decode($raw,true); $text=''; if(isset($j['output'])){foreach($j['output'] as $item){foreach(($item['content']??[]) as $c){if(isset($c['text'])) $text.=$c['text'];}}}
if(!$text) $text=$j['output_text'] ?? 'No text returned.';
echo json_encode(['title'=>"$subject — $topic",'content'=>$text]);
